package UI;

import com.sun.javafx.robot.impl.FXRobotHelper;
import data.AvailableBooks;
import data.RentedBooks;
import data.ShowBooks;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import librarysystem.function;

import java.io.IOException;
import java.rmi.server.UID;
import java.time.LocalDate;
import java.util.List;

public class AdminController {
    function library = new function();
    @FXML
    TextField title;
    @FXML
    TextField author;
    @FXML
    TextField shelf;
    @FXML
    TextField genre;
    @FXML
    TextField publisher;
    @FXML
    Button addBook;
    @FXML
    Button deleteBook;
    @FXML
    Button addUser;
    @FXML
    Button deleteUser;
    @FXML
    TableView bookList;
    @FXML
    TableColumn t_name;
    @FXML
    TableColumn t_author;
    @FXML
    TableColumn t_genre;
    @FXML
    TableColumn t_publisher;
    @FXML
    TableColumn t_copies;
    @FXML
    TableColumn t_rentTime;
    @FXML
    TableColumn t_shelfNum;
    @FXML
    TextField bookTitle;
    @FXML
    TextField userName;
    @FXML
    Button s_author;
    @FXML
    Button s_title;
    @FXML
    TextField author_input;
    @FXML
    TextField title_input;


    public AdminController() {
        library.readAvailableBooksToFile();
        library.readRentedBooksFromFile();
        library.readUserFromFile();
    }


    @FXML
    public void logout(){
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Home.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

    @FXML
    public void addNewBook(){
        if(!title.getText().equals("")&&!author.getText().equals("")&&!genre.getText().equals("")&&!publisher.getText().equals("")&&!shelf.getText().equals("")) {
            library.addBook(title.getText(), author.getText(), genre.getText(), publisher.getText(), shelf.getText());
            Alert information = new Alert(Alert.AlertType.INFORMATION, "Add new book successfully");
            information.showAndWait();
            library.saveAvailableBooksToFile();
        }else {
            Alert information = new Alert(Alert.AlertType.INFORMATION, "Please complete the info");
            information.showAndWait();
        }
    }
    
    @FXML
    public void deleteBook() {
        if(library.retriveBook(bookTitle.getText()) != null) {
            library.deleteBook(bookTitle.getText(), author.getText(), genre.getText(), publisher.getText(), shelf.getText());
            library.saveAvailableBooksToFile();
            Alert information = new Alert(Alert.AlertType.INFORMATION, "Delete book successfully");
            information.showAndWait();
        }else {
            Alert information = new Alert(Alert.AlertType.INFORMATION, "This book does not exist");
            information.showAndWait();
        }
    }

    @FXML
    public void addNewUser(){
        UIData.isAdmin = true;
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Register.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }
    
    @FXML
    public void deleteUser() {
    	if(library.retriveUser(userName.getText())!=null) {
            library.deleteUser("",userName.getText(),"","","","");
            library.saveUserToFile();
            Alert information = new Alert(Alert.AlertType.INFORMATION, "Delete user successfully");
            information.showAndWait();
        }else {
            Alert information = new Alert(Alert.AlertType.INFORMATION, "This User does not exist");
            information.showAndWait();
        }
    }
    
    @FXML
    public void sortAuthor(){
        library.sortAuthor();
        showAllBooks();

        library.saveAvailableBooksToFile();
    }

    @FXML
    public void sortTitle(){
        library.sortTitle();
        showAllBooks();

        library.saveAvailableBooksToFile();
    }

    @FXML
    public void sortTime(){
        library.sortTimesRentedOut();
        showAllBooks();

        library.saveAvailableBooksToFile();

    }

    public void showAllBooks(){
        List<AvailableBooks> availableBooksList = library.getBooklist();
        ObservableList<ShowBooks> list = FXCollections.observableArrayList();

        t_name.setCellValueFactory(new PropertyValueFactory("title"));
        t_author.setCellValueFactory(new PropertyValueFactory("author"));
        t_genre.setCellValueFactory(new PropertyValueFactory("genre"));
        t_publisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        t_copies.setText("Copies");
        t_copies.setPrefWidth(150);
        t_copies.setCellValueFactory(new PropertyValueFactory("copy"));
        t_rentTime.setText("RentTime");
        t_rentTime.setPrefWidth(150);
        t_rentTime.setCellValueFactory(new PropertyValueFactory("timesBookBeenRentedOut"));
        t_shelfNum.setVisible(true);
        t_shelfNum.setCellValueFactory(new PropertyValueFactory("shelf"));
        int sum;


        for(AvailableBooks availableBooks : availableBooksList) {
            if (availableBooks.getCopy() > 0) {
                list.add(new ShowBooks(availableBooks.getTitle(),availableBooks.getAuthor(),availableBooks.getGenre(),availableBooks.getPublisher(),availableBooks.getShelf(),availableBooks.getCopy()+"",+availableBooks.getTimeBookRentedOut()+""));
            }
        }
        bookList.setItems(list);
    }

    public void showAllDelayedBooks(){
        List<RentedBooks> delayedBooks = library.getRentedBooklist();
        ObservableList<RentedBooks> list = FXCollections.observableArrayList();

        t_name.setCellValueFactory(new PropertyValueFactory("title"));
        t_author.setCellValueFactory(new PropertyValueFactory("author"));
        t_genre.setCellValueFactory(new PropertyValueFactory("genre"));
        t_publisher.setCellValueFactory(new PropertyValueFactory("publisher"));

        t_copies.setText("rentOutDate");
        t_copies.setPrefWidth(240);
        t_copies.setCellValueFactory(new PropertyValueFactory("rentOutDate"));
        t_rentTime.setText("returnDate");
        t_rentTime.setPrefWidth(220);
        t_rentTime.setCellValueFactory(new PropertyValueFactory("returnDate"));
        t_shelfNum.setVisible(false);

        for(RentedBooks rentedBooks : delayedBooks) {
            if(rentedBooks.exactDay(LocalDate.now().toString()) < 0)
                list.add(rentedBooks);
        }
        bookList.setItems(list);

        if(list.size() == 0){
            Alert information = new Alert(Alert.AlertType.INFORMATION, "Library is empty!");
            information.showAndWait();
        }
    }

    @FXML
    public void change(){
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Change.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

    @FXML
    public void searchBookByAuthor(){
        List<AvailableBooks> availableBooksList = library.retriveBooksByAuthor(author_input.getText());
        ObservableList<ShowBooks> list = FXCollections.observableArrayList();

        t_name.setCellValueFactory(new PropertyValueFactory("title"));
        t_author.setCellValueFactory(new PropertyValueFactory("author"));
        t_genre.setCellValueFactory(new PropertyValueFactory("genre"));
        t_publisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        t_copies.setText("Copies");
        t_copies.setPrefWidth(150);
        t_copies.setCellValueFactory(new PropertyValueFactory("copy"));
        t_rentTime.setText("RentTime");
        t_rentTime.setPrefWidth(150);
        t_rentTime.setCellValueFactory(new PropertyValueFactory("timesBookBeenRentedOut"));
        t_shelfNum.setVisible(true);
        t_shelfNum.setCellValueFactory(new PropertyValueFactory("shelf"));

        for(AvailableBooks availableBooks : availableBooksList) {
            if (availableBooks.getCopy() > 0) {
                list.add(new ShowBooks(availableBooks.getTitle(),availableBooks.getAuthor(),availableBooks.getGenre(),availableBooks.getPublisher(),availableBooks.getShelf(),availableBooks.getCopy()+"",+availableBooks.getTimeBookRentedOut()+""));
            }
        }
        bookList.setItems(list);
    }

    @FXML
    public void searchBookByTitle(){
        List<AvailableBooks> availableBooksList = library.retriveBooksByTitle(title_input.getText());
        ObservableList<ShowBooks> list = FXCollections.observableArrayList();

        t_name.setCellValueFactory(new PropertyValueFactory("title"));
        t_author.setCellValueFactory(new PropertyValueFactory("author"));
        t_genre.setCellValueFactory(new PropertyValueFactory("genre"));
        t_publisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        t_copies.setText("Copies");
        t_copies.setPrefWidth(150);
        t_copies.setCellValueFactory(new PropertyValueFactory("copy"));
        t_rentTime.setText("RentTime");
        t_rentTime.setPrefWidth(150);
        t_rentTime.setCellValueFactory(new PropertyValueFactory("timesBookBeenRentedOut"));
        t_shelfNum.setVisible(true);
        t_shelfNum.setCellValueFactory(new PropertyValueFactory("shelf"));

        for(AvailableBooks availableBooks : availableBooksList) {
            if (availableBooks.getCopy() > 0) {
                list.add(new ShowBooks(availableBooks.getTitle(),availableBooks.getAuthor(),availableBooks.getGenre(),availableBooks.getPublisher(),availableBooks.getShelf(),availableBooks.getCopy()+"",+availableBooks.getTimeBookRentedOut()+""));
            }
        }
        bookList.setItems(list);
    }


}
