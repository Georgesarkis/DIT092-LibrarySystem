package UI;

import com.sun.javafx.robot.impl.FXRobotHelper;
import data.AvailableBooks;
import data.RentedBooks;
import data.ShowBooks;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import librarysystem.function;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class UserController {
    function library = new function();
    @FXML
    Button ShowBookList;
    @FXML
    TableView bookList;
    @FXML
    TableColumn name;
    @FXML
    TableColumn author;
    @FXML
    TableColumn genre;
    @FXML
    TableColumn publisher;
    @FXML
    TableColumn copies;
    @FXML
    TableColumn rentTime;
    @FXML
    TableColumn shelfNum;
    @FXML
    TextField rentBook;
    @FXML
    TextField returnBook;
    @FXML
    TextField check;

    @FXML
    TableView historyList;
    @FXML
    TableColumn historyName;
    @FXML
    TableColumn historyAuthor;
    @FXML
    TableColumn historyGenre;
    @FXML
    TableColumn historyPublisher;
    @FXML
    TableColumn historyRentTime;
    @FXML
    TableColumn historyReturnTime;

    @FXML
    Button s_author;
    @FXML
    Button s_title;
    @FXML
    TextField author_input;
    @FXML
    TextField title_input;



    public UserController() {
        library.readAvailableBooksToFile();
        library.readRentedBooksFromFile();
        library.readUserFromFile();
    }

    @FXML
    public void showAllBooks(){
        List<AvailableBooks> availableBooksList = library.getBooklist();
        ObservableList<ShowBooks> list = FXCollections.observableArrayList();

        int temp;
        name.setCellValueFactory(new PropertyValueFactory("title"));
        author.setCellValueFactory(new PropertyValueFactory("author"));
        genre.setCellValueFactory(new PropertyValueFactory("genre"));
        publisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        copies.setCellValueFactory(new PropertyValueFactory("copy"));
        rentTime.setCellValueFactory(new PropertyValueFactory("timesBookBeenRentedOut"));
        shelfNum.setCellValueFactory(new PropertyValueFactory("shelf"));


        for(AvailableBooks availableBooks : availableBooksList) {
            if (availableBooks.getCopy() > 0) {
                list.add(new ShowBooks(availableBooks.getTitle(),availableBooks.getAuthor(),availableBooks.getGenre(),availableBooks.getPublisher(),availableBooks.getShelf(),availableBooks.getCopy()+"",+availableBooks.getTimeBookRentedOut()+""));
            }
        }
        bookList.setItems(list);
    }

    @FXML
    public void logout(){
        UIData.userData = null;
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Home.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

    @FXML
    public void rentBook(){
        String result = library.rentOutBook(rentBook.getText(), UIData.userData, LocalDate.now());
        Alert information = new Alert(Alert.AlertType.INFORMATION,result);
        information.showAndWait();

        library.saveAvailableBooksToFile();
        library.saveRentedBooksToFile();
        library.saveUserToFile();
    }

    @FXML
    public void returnBook(){
        String result = "Failed";
        try {
            result =  library.returnBook(returnBook.getText(), UIData.userData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Alert information = new Alert(Alert.AlertType.INFORMATION,result);
        information.showAndWait();

        library.saveAvailableBooksToFile();
        library.saveRentedBooksToFile();
        library.saveUserToFile();

    }

    @FXML
    public void check(){
        String result = "Failed";
        int temp = 0;
        try {
            result =  library.returnBook(check.getText(), UIData.userData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Alert information = new Alert(Alert.AlertType.INFORMATION,result);
        information.showAndWait();

        library.saveAvailableBooksToFile();
        library.saveRentedBooksToFile();
        library.saveUserToFile();
    }

    @FXML
    public void showHistory(){
        List<RentedBooks> rentedBooksList = UIData.userData.history;
        ObservableList<RentedBooks> list = FXCollections.observableArrayList();

        historyName.setCellValueFactory(new PropertyValueFactory("title"));
        historyAuthor.setCellValueFactory(new PropertyValueFactory("author"));
        historyGenre.setCellValueFactory(new PropertyValueFactory("genre"));
        historyPublisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        historyRentTime.setCellValueFactory(new PropertyValueFactory("rentOutDate"));
        historyReturnTime.setCellValueFactory(new PropertyValueFactory("returnDate"));


        for(RentedBooks rentedBooks : rentedBooksList)
            list.add(rentedBooks);

        historyList.setItems(list);
    }

    @FXML
    public void searchBookByAuthor(){
        List<AvailableBooks> availableBooksList = library.retriveBooksByAuthor(author_input.getText());
        ObservableList<ShowBooks> list = FXCollections.observableArrayList();

        name.setCellValueFactory(new PropertyValueFactory("title"));
        author.setCellValueFactory(new PropertyValueFactory("author"));
        genre.setCellValueFactory(new PropertyValueFactory("genre"));
        publisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        copies.setCellValueFactory(new PropertyValueFactory("copy"));
        rentTime.setCellValueFactory(new PropertyValueFactory("timesBookBeenRentedOut"));
        shelfNum.setCellValueFactory(new PropertyValueFactory("shelf"));

        for(AvailableBooks availableBooks : availableBooksList) {
            if (availableBooks.getCopy() > 0) {
                list.add(new ShowBooks(availableBooks.getTitle(),availableBooks.getAuthor(),availableBooks.getGenre(),availableBooks.getPublisher(),availableBooks.getShelf(),availableBooks.getCopy()+"",+availableBooks.getTimeBookRentedOut()+""));
            }
        }
        bookList.setItems(list);
    }

    @FXML
    public void searchBookByTitle(){
        List<AvailableBooks> availableBooksList = library.retriveBooksByTitle(title_input.getText());
        ObservableList<ShowBooks> list = FXCollections.observableArrayList();

        name.setCellValueFactory(new PropertyValueFactory("title"));
        author.setCellValueFactory(new PropertyValueFactory("author"));
        genre.setCellValueFactory(new PropertyValueFactory("genre"));
        publisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        copies.setCellValueFactory(new PropertyValueFactory("copy"));
        rentTime.setCellValueFactory(new PropertyValueFactory("timesBookBeenRentedOut"));
        shelfNum.setCellValueFactory(new PropertyValueFactory("shelf"));

        for(AvailableBooks availableBooks : availableBooksList) {
            if (availableBooks.getCopy() > 0) {
                list.add(new ShowBooks(availableBooks.getTitle(),availableBooks.getAuthor(),availableBooks.getGenre(),availableBooks.getPublisher(),availableBooks.getShelf(),availableBooks.getCopy()+"",+availableBooks.getTimeBookRentedOut()+""));
            }
        }
        bookList.setItems(list);
    }

}
