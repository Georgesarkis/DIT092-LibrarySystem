package UI;

import librarysystem.*;

import java.time.LocalDate;
import java.util.Scanner;
import data.*;

public class libraryUI {
	private Scanner input = new Scanner(System.in);
	function library = new function();

	public static void main(String[] args) {
		libraryUI program = new libraryUI();
		program.welcome();
	}

	public void welcome() {
		System.out.println("------------------------------------");
		System.out.println("***********Library System***********");
		System.out.println("------------------------------------");
		library.readAvailableBooksToFile();
		library.readRentedBooksFromFile();
		library.readUserFromFile();
		showMenu();
	}

	public void showMenu() {
		final int LOGIN = 1;
		final int AVILABLEBOOKS = 2;
		final int REGISTERCOSTUMER = 3;
		final int ADMIN = 4;
		final int QUIT = 5;
		int ans;
		do {
			System.out.println("to login press 1");
			System.out.println("to look available books press 2");
			System.out.println("to register new customer press 3");
			System.out.println("in case of admin press 4");
			System.out.println("to quit press 5");
			ans = input.nextInt();
			input.nextLine(); // removing any leftover

			switch (ans) {
			case LOGIN:
				loginMain();
				break;
			case AVILABLEBOOKS:
				System.out.println(library.printAvilableBook());
				break;
			case REGISTERCOSTUMER:
				registerCustMain();
				break;
			case ADMIN:
				adminMenu();
				break;

			case QUIT:
				break;

			default:
				System.out.println("Option " + ans + " is not valid.");
				System.out.println();
			}

		} while (ans != QUIT);
		{
			System.out.println("Goodbye");
			library.saveAvailableBooksToFile();
			library.saveRentedBooksToFile();
			library.saveUserToFile();
			System.exit(0);
		}

	}

	private void adminMenu() {
		final int ADDBOOK = 1;
		final int REGISTERCOSTUMER = 2;
		final int SORTATHURS = 3;
		final int SORTTITLE = 4;
		final int SORTTIMESRENTEDOUT = 5;
		final int CHANGEINFO = 6;
		final int LOGOUT = 7;
		System.out.println("please enter the admins' password: ");
		String pass = input.nextLine();
		int ans;
		if (pass.equals("123456")) {
			do {
				System.out.println("to add book press 1 ");
				System.out.println("to add new user press 2");
				System.out.println("to sort books base on authors press 3");
				System.out.println("to sort books based on title press 4");
				System.out
						.println("to sort books based on number of times it's rented out press 5");
				System.out
						.println("to change or retrieve information of an user press 6");
				System.out.println("to logout press 7");
				ans = input.nextInt();
				input.nextLine(); // clearing the scanner

				switch (ans) {
				case ADDBOOK:
					System.out.println("Enter the book title");
					String title = input.nextLine();
					System.out.println("Enter the book author");
					String author = input.nextLine();
					System.out.println("Enter the book's shelf");
					String shelf = input.nextLine();
					System.out.println("Enter the book's genre:");
					String genre = input.nextLine();
					System.out.println("Enter the book's publisher: ");
					String publisher = input.nextLine();
					try {
						library.addBook(title, author, genre, publisher, shelf);
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case REGISTERCOSTUMER:
					registerCustMain();
					break;
				case SORTATHURS:
					library.sortAuthor();
					System.out.print(library.printAvilableBook());
					break;
				case SORTTITLE:
					library.sortTitle();
					System.out.print(library.printAvilableBook());
					break;
				case SORTTIMESRENTEDOUT:
					library.sortTimesRentedOut();
					System.out.print(library.printAvilableBook());
					break;
				case CHANGEINFO:
					try {
						changeRetriveCostumerInfo();
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case LOGOUT: {
					break;
				}
				default:
					System.out.println("Option " + ans + " is not valid.");
					System.out.println();
				}
			} while (ans != LOGOUT);
			{
				showMenu();
			}
		} else {
			System.out.println("WRONG PASSWORD");
			showMenu();
		}
	}

	private void changeRetriveCostumerInfo() throws Exception {
		final int CHANGENAME = 1;
		final int CHANGEPASS = 2;
		final int RETRIVEPASS = 3;
		final int CHANGEEMAIL = 4;
		final int RETRIVEEMAIL = 5;
		final int CHANGENUM = 6;
		final int RETRIVENUM = 7;
		final int MAINMENU = 8;
		int ans;
		do {
			System.out.println("Enter the customers name:");
			String name = input.nextLine();
			UserData user = library.checkCustemerForAdmin(name);
			System.out.println("to change customer's name press 1");
			System.out.println("to change customer's password press 2");
			System.out.println("to retrive customer's password press 3");
			System.out.println("to change customer's email press 4");
			System.out.println("to retrieve customer's email press 5");
			System.out.println("to change customer's phone number press 6");
			System.out.println("to retrieve customer's phone number press 7");
			System.out.println("to go back to main menu press 8");
			ans = input.nextInt();
			input.nextLine(); // clearing scanner

			switch (ans) {
			case CHANGENAME:
				System.out.println("Enter the new name:");
				String newName = input.nextLine();
				user.setName(newName);
				break;
			case CHANGEPASS:
				System.out.println("Enter the new passwrod:");
				String pass = input.nextLine();
				user.setPassword(pass);
				break;
			case RETRIVEPASS:
				System.out.println(user.getPassword());
				break;
			case CHANGEEMAIL:
				System.out.println("Enter the new Email:");
				String email = input.nextLine();
				user.setEmail(email);
				break;
			case RETRIVEEMAIL:
				System.out.println(user.getEmail());
				break;
			case CHANGENUM:
				System.out.println("Enter the new phone number: ");
				String num = input.nextLine();
				user.setTeleNumber(num);
				break;
			case RETRIVENUM:
				System.out.println(user.getTeleNumber());
				break;
			case MAINMENU:
				showMenu();
				break;
			default:
				System.out.println("Option " + ans + " is not valid.");
				System.out.println();
			}
		} while (ans != MAINMENU);
		{
			showMenu();
		}

	}

	private void registerCustMain() {
		boolean occpied = true;
		String userName;
		System.out.println("Enter the name:");
		String name = input.nextLine();
		do {
			System.out.println("Enter the userName: ");
			userName = input.nextLine();
			occpied = library.checkUserName(userName);
		} while (occpied == true);
		System.out.println("Enter the user Email: ");
		String email = input.nextLine();
		System.out.println("Enter the password:");
		String pass = input.nextLine();
		System.out.println("Enter the user phoneNumber: ");
		String num = input.nextLine();
		System.out.println("Enter the user's adress");
		String adress = input.nextLine();
		library.createNewUser(name, userName, pass, email, num, adress);
	}

	private void loginMain() {
		System.out.println("write username");
		String username = input.nextLine();
		System.out.println("write password");
		String pass = input.nextLine();
		UserData user = library.checkCustemer(username, pass); // create after
																// class forMe
		if (user != null) {
			try {
				costumerMian(user);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			System.out
					.println("\"customer is not registered or invalid username / password\"");
		}
	}

	private void costumerMian(UserData user) throws Exception {
		int ans;
		final int AVILABLEBOOKS = 1;
		final int RENTBOOK = 2;
		final int RETURNBOOKS = 3;
		final int CHECKRENTEDBOOK = 4;
		final int CHECKHISTORY = 5;
		final int LOGOUT = 6;
		do {
			System.out.println("to find available books press 1");
			System.out.println("to rent a book press 2");
			System.out.print("to return a book press 3");
			System.out.println("to check rented book press 4");
			System.out.println("to check rented history press 5");
			System.out.println("to logout and go back to menu press 6");
			ans = input.nextInt();
			input.nextLine();

			switch (ans) {
			case AVILABLEBOOKS:
				System.out.println(library.printAvilableBook());
				break;
			case RENTBOOK:
				System.out.println("enter the book title: ");
				String name = input.nextLine();
				LocalDate today = LocalDate.now();
				System.out.println(library.rentOutBook(name, user, today));
				break;
			case RETURNBOOKS:
				System.out.println("enter the book title:");
				String title = input.nextLine();
				library.returnBook(title, user);
				break;
			case CHECKRENTEDBOOK:
				System.out.println("enter the book you want to return: ");
				String name1 = input.nextLine();
				System.out.println(library.returnBook(name1, user));

				break;
			case CHECKHISTORY:
				System.out.println(user.getHistory());
				break;
			case LOGOUT:
				break;
			default:
				System.out.println("Option " + ans + " is not valid.");
				System.out.println();
			}
		} while (ans != LOGOUT);
		{
			showMenu();
		}
	}

}
