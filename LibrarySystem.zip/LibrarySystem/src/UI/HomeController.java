package UI;

import com.sun.javafx.robot.impl.FXRobotHelper;
import data.AvailableBooks;
import data.ShowBooks;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import librarysystem.function;

import java.io.IOException;
import java.util.List;

public class HomeController {
    function library = new function();
    @FXML
    Button ShowBookList;
    @FXML
    TableView bookList;
    @FXML
    TableColumn name;
    @FXML
    TableColumn author;
    @FXML
    TableColumn genre;
    @FXML
    TableColumn publisher;
    @FXML
    TableColumn copies;
    @FXML
    TableColumn rentTime;
    @FXML
    TableColumn shelfNum;
    @FXML
    Button register;
    @FXML
    Button login;
    @FXML
    Button admin;


    public HomeController() {
        library.readAvailableBooksToFile();
        library.readRentedBooksFromFile();
        library.readUserFromFile();
    }

    @FXML
    public void showAllBooks(){
        List<AvailableBooks> availableBooksList = library.getBooklist();
        ObservableList<ShowBooks> list = FXCollections.observableArrayList();

        name.setCellValueFactory(new PropertyValueFactory("title"));
        author.setCellValueFactory(new PropertyValueFactory("author"));
        genre.setCellValueFactory(new PropertyValueFactory("genre"));
        publisher.setCellValueFactory(new PropertyValueFactory("publisher"));
        copies.setCellValueFactory(new PropertyValueFactory("copy"));
        rentTime.setCellValueFactory(new PropertyValueFactory("timesBookBeenRentedOut"));
        shelfNum.setCellValueFactory(new PropertyValueFactory("shelf"));


        for(AvailableBooks availableBooks : availableBooksList) {
            if (availableBooks.getCopy() > 0) {
                list.add(new ShowBooks(availableBooks.getTitle(),availableBooks.getAuthor(),availableBooks.getGenre(),availableBooks.getPublisher(),availableBooks.getShelf(),availableBooks.getCopy()+"",+availableBooks.getTimeBookRentedOut()+""));
            }
        }
        bookList.setItems(list);
    }

    @FXML
    public void login(){
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Login.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

    @FXML
    public void register(){
        UIData.isAdmin = false;
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Register.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

    @FXML
    public void admin(){
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("AdminLogin.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

}
