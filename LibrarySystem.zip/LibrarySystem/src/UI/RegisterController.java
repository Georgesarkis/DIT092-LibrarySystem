package UI;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import librarysystem.function;

import java.io.IOException;

public class RegisterController {
    function library = new function();
    @FXML
    TextField name;
    @FXML
    TextField userName;
    @FXML
    TextField email;
    @FXML
    PasswordField pwd;
    @FXML
    TextField phone;
    @FXML
    TextField address;

    public RegisterController() {
        library.readAvailableBooksToFile();
        library.readRentedBooksFromFile();
        library.readUserFromFile();
    }

    @FXML
    public void register(){
        if(!library.checkUserName(userName.getText())){
            library.createNewUser(name.getText(), userName.getText(), pwd.getText(), email.getText(), phone.getText(), address.getText());
            Alert information = new Alert(Alert.AlertType.INFORMATION,"Register successfully!");
            information.showAndWait();
        }
        Alert information = new Alert(Alert.AlertType.INFORMATION,"The username has been used");
        information.showAndWait();

        library.saveUserToFile();

    }

    @FXML
    public void back(){
        String name = "";
        if(UIData.isAdmin)
            name = "Admin.fxml";
        else
            name = "Home.fxml";

        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource(name)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

}
