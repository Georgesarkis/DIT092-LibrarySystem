package UI;

import data.UserData;

public class UIData {
    public static UserData userData;
    public static Boolean isAdmin = false;
    public static UserData changeUser;
}
