package UI;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import librarysystem.function;

import java.io.IOException;


public class LoginController {
    function library = new function();
    @FXML
    TextField userNameInput;
    @FXML
    PasswordField pwdInpit;
    @FXML
    Button loginConfirm;
    @FXML
    Button back;

    public LoginController() {
        library.readAvailableBooksToFile();
        library.readRentedBooksFromFile();
        library.readUserFromFile();
    }

    public void back(){
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Home.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }

    public void confirm(){
        UIData.userData = library.checkCustemer(userNameInput.getText(), pwdInpit.getText());
        if(UIData.userData != null){
            ObservableList<Stage> stage = FXRobotHelper.getStages();
            Scene scene = null;
            try {
                scene = new Scene(FXMLLoader.load(getClass().getResource("User.fxml")));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.get(0).setScene(scene);
        }else{
            Alert information = new Alert(Alert.AlertType.INFORMATION,"customer is not registered or invalid username / password");
            information.showAndWait();
        }
    }


}
