package UI;

import com.sun.javafx.robot.impl.FXRobotHelper;
import data.UserData;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import librarysystem.function;

import java.io.IOException;

public class ChangeController {
    function library = new function();
    @FXML
    TextField inputUserName;

    @FXML
    TextField name;
    @FXML
    TextField pwd;
    @FXML
    TextField email;
    @FXML
    TextField phone;

    @FXML
    Button resetName;
    @FXML
    Button resetPWD;
    @FXML
    Button resetEmail;
    @FXML
    Button resetPhone;


    public ChangeController() {
        library.readAvailableBooksToFile();
        library.readRentedBooksFromFile();
        library.readUserFromFile();
    }

    @FXML
    public void check(){
        UserData user = library.checkCustemerForAdmin(inputUserName.getText());
        UIData.changeUser = user;
        if(user == null){
            Alert information = new Alert(Alert.AlertType.INFORMATION, "This user not exists!");
            information.showAndWait();

            resetName.setVisible(false);
            resetPWD.setVisible(false);
            resetEmail.setVisible(false);
            resetPhone.setVisible(false);

        }else {
            resetName.setVisible(true);
            resetPWD.setVisible(true);
            resetEmail.setVisible(true);
            resetPhone.setVisible(true);

            name.setText(user.getName());
            pwd.setText(user.getPassword());
            email.setText(user.getEmail());
            phone.setText(user.getTeleNumber());
        }
    }

    @FXML
    public void resetName(){
        UIData.changeUser.setName(name.getText());
        library.saveUserToFile();
        Alert information = new Alert(Alert.AlertType.INFORMATION, "Success");
        information.showAndWait();
    }

    @FXML
    public void resetPWD(){
        UIData.changeUser.setPassword(pwd.getText());
        library.saveUserToFile();
        Alert information = new Alert(Alert.AlertType.INFORMATION, "Success");
        information.showAndWait();
    }

    @FXML
    public void resetEmail(){
        UIData.changeUser.setEmail(email.getText());
        library.saveUserToFile();
        Alert information = new Alert(Alert.AlertType.INFORMATION, "Success");
        information.showAndWait();
    }

    @FXML
    public void resetPhone(){
        UIData.changeUser.setTeleNumber(phone.getText());
        library.saveUserToFile();
        Alert information = new Alert(Alert.AlertType.INFORMATION, "Success");
        information.showAndWait();
    }

    @FXML
    public void back(){
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Admin.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }
}
