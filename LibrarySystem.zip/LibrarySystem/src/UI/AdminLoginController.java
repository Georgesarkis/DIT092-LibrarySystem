package UI;

import com.sun.javafx.robot.impl.FXRobotHelper;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminLoginController {
    @FXML
    PasswordField adminPWD;

    @FXML
    public void confirmAndLogin(){
        if(adminPWD.getText().equals("123456")){
            ObservableList<Stage> stage = FXRobotHelper.getStages();
            Scene scene = null;
            try {
                scene = new Scene(FXMLLoader.load(getClass().getResource("Admin.fxml")));
            } catch (IOException e) {
                e.printStackTrace();
            }
            stage.get(0).setScene(scene);
        }else {
            Alert information = new Alert(Alert.AlertType.INFORMATION,"Password is incorrect,Please try again");
            information.showAndWait();
        }
    }

    @FXML
    public void back(){
        ObservableList<Stage> stage = FXRobotHelper.getStages();
        Scene scene = null;
        try {
            scene = new Scene(FXMLLoader.load(getClass().getResource("Home.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        stage.get(0).setScene(scene);
    }
}
