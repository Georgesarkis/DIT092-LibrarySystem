package librarysystem;

/**
 *  
 *  @author George Sarkisian <georgesako@gmail.com>
 *  @version 1.0
 *  @since 2017-08-12
 *  
 *  This class saves and reads list in .json file
 *  Please install Gson library on your eclipse to make the program run without errors.
 */


import java.io.*;
import java.lang.reflect.Type;
import java.util.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;


public class ReadAndWrite {
	Gson objGson = new GsonBuilder().setPrettyPrinting().create();

	public void saveGson(List list, String fileName) {
		try {
			String name = fileName+".json";
			FileOutputStream file = new FileOutputStream(name);
			String s = objGson.toJson(list);
			Writer writer = new FileWriter(name);
			writer.write(s);
			writer.close();
			file.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List readGson(String fileName) {
		List list = new ArrayList<>();
		try {
			String name = fileName+".json";
			File pointFile = new File(name);
			Scanner pointReader = new Scanner(pointFile);
			String gson = pointReader.nextLine();
			Type listType = new TypeToken<List>() {}.getType();
			list = objGson.fromJson(gson, listType);
			pointReader.close();
		}catch(FileNotFoundException fnf) {
			fnf.printStackTrace();
		}
		return list;
	}
}

	
