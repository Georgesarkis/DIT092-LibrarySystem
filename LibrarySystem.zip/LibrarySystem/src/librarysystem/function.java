package librarysystem;

import java.util.*;
import java.io.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import data.*;

public class function {
	private List<AvailableBooks> booklist;
	private List<UserData> userlist;
	private List<RentedBooks> rentedBooklist;
	private final int RENT_DAYS = 14;
	
	public function() {
		this.booklist = new ArrayList<>();
		this.userlist = new ArrayList<>();
		this.rentedBooklist = new ArrayList<>();
	}	


	public List<AvailableBooks> getBooklist() {
		return booklist;
	}

	public void setBooklist(List<AvailableBooks> booklist) {
		this.booklist = booklist;
	}

	public List<UserData> getUserlist() {
		return userlist;
	}

	public void setUserlist(List<UserData> userlist) {
		this.userlist = userlist;
	}

	public List<RentedBooks> getRentedBooklist() {
		return rentedBooklist;
	}

	public void setRentedBooklist(List<RentedBooks> rentedBooklist) {
		this.rentedBooklist = rentedBooklist;
	}

	public AvailableBooks retriveBook(String title) { // give the books position
														// inside the list
		for (int i = 0; i < booklist.size(); i++) {
			if (booklist.get(i).getTitle().equals(title)) {
				return booklist.get(i);
			}
		}
		return null;
	}
	
	public List<AvailableBooks> retriveBooksByAuthor(String author) {
		List<AvailableBooks> booksList = new ArrayList<>();
		for (int i = 0; i < booklist.size(); i++) {
			if (booklist.get(i).getAuthor().equals(author)) {
				booksList.add(booklist.get(i));
			}
		}
		return booksList;
	}

	public List<AvailableBooks> retriveBooksByTitle(String title) {
		List<AvailableBooks> booksList = new ArrayList<>();
		for (int i = 0; i < booklist.size(); i++) {
			if (booklist.get(i).getTitle().equals(title)) {
				booksList.add(booklist.get(i));
			}
		}
		return booksList;
	}

	public boolean checkUserName(String a) {
		if (userlist.size() == 0) {
			return false;
		} else {
			for (int i = 0; i < userlist.size(); i++) {
				if (userlist.get(i).getUserName().equals(a)) {
					System.out
							.println("Username is already taken, please try another");
					return true;
				}

			}
		}
		return false;
	}
	
	public UserData retriveUser(String userName) {
		for (int i = 0; i < userlist.size(); i++) {
			if (userlist.get(i).getUserName().equals(userName)) {
				return userlist.get(i);
			}
		}
		return null;
	}

	public void createNewUser(String name, String userName, String pass,
			String email, String number, String adress) {
		UserData user = new UserData(name, userName, pass, email, number,
				adress);
		userlist.add(user);
	}
	
	public void deleteUser(String name, String userName, String pass,
			String email, String number, String adress) {
		UserData foundUser = retriveUser(userName);
		userlist.remove(foundUser);
	}

	public String rentOutBook(String name, UserData user, LocalDate today) {
		AvailableBooks book = retriveBook(name);
		LocalDate next2Week = today.plus(2, ChronoUnit.WEEKS);
		if (book != null && book.getCopy() >= 1) {
			RentedBooks rentedBook = new RentedBooks(book.getTitle(),
					book.getAuthor(), book.getGenre(), book.getPublisher(),
					today.toString(), next2Week.toString());
			book.rentCopy();
			rentedBooklist.add(rentedBook);
			user.addRentedBook(rentedBook);
			return book.getTitle() + " was successfully rented out to user: "
					+ user.getUserName();
		}
		return "The book was not found.";
	}

	// return i bookis secssesfully returned and show amoit to pay
	public String returnBook(String name, UserData user) throws Exception {
		int fee = 0;

		RentedBooks foundBook = user.checkRentedBooks(name);
		if (foundBook != null) {
			fee = overDaysFee(foundBook);
			user.deleteRentedBook(foundBook);
			user.setHistory(foundBook);
			rentedBooklist.remove(foundBook);
			AvailableBooks foundAvailable = retriveBook(name);
			foundAvailable.addCopy();
			return "Amount to pay: " + fee;
		}

		return "The book is not rented by this user. ";
	}

	public int overDaysFee(RentedBooks book) { // return amont to pay if the
												// retrun day is over t 2 weeks
		LocalDate today = LocalDate.now();
		int amountToPay = 0;
		if (book.exactDay(today.toString()) > RENT_DAYS) {
			amountToPay = (book.exactDay(today.toString()) - RENT_DAYS) * 2;

			return amountToPay;
		} else
			return amountToPay;
	}

	// check if the user is available check their user name and password
	public UserData checkCustemer(String username, String password) {

		for (int i = 0; i < userlist.size(); i++) {
			if ((userlist.get(i).getUserName().equals(username))
					&& (userlist.get(i).getPassword().equals(password))) {

				return userlist.get(i);
			}
		}
		return null;
	}

	public UserData checkCustemerForAdmin(String name) { // check if the user is
															// available check
															// their username
		for (int i = 0; i < userlist.size(); i++) {
			if (userlist.get(i).getName().equals(name)) {
				return userlist.get(i);
			}
		}
		return null;
	}

	public String printAvilableBook() { // print all available books inside
										// library
		String list = "";
		if (booklist.size() == 0) {
			return "Library is empty";
		} else {
			for (int i = 0; i < booklist.size(); i++) {
				if (booklist.get(i).getCopy() > 0) {
					list += booklist.get(i).toString();
				}
			}
		}
		return list;
	}

	public void addBook(String title, String author, String genre,
			String publisher, String shelf) { // add new books, check if it
												// already excit in library then
												// add copy
		AvailableBooks foundBook = retriveBook(title);
		if (foundBook != null) {
			foundBook.addCopy();
		} else {
			AvailableBooks newBook = new AvailableBooks(title, author, genre,
					publisher, shelf);
			booklist.add(newBook);
		}
	}
	
	public void deleteBook(String title, String author, String genre,
			String publisher, String shelf) {
		AvailableBooks foundBook = retriveBook(title);
		booklist.remove(foundBook);	
	}

	public void sortAuthor() {
		Collections.sort(booklist, AvailableBooks.getCompByAuthor());
	}

	public void sortTitle() {
		Collections.sort(booklist, AvailableBooks.getCompByTitle());
	}

	public void sortTimesRentedOut() {
		Collections.sort(booklist, AvailableBooks.getCompByTimeRentedOut());
	}

	public String printDelayed() {
		LocalDate today = LocalDate.now();
		String list = "";
		if (rentedBooklist.size() == 0) {
			return "Library is empty";
		} else {
			for (int i = 0; i < rentedBooklist.size(); i++) {
				if (rentedBooklist.get(i).exactDay(today.toString()) < 0) {
					list += rentedBooklist.get(i).toString();
				}
			}
		}
		return list;
	}

	public void saveAvailableBooksToFile() {
		try {
			// to create a file
			File bookFile = new File("availableBookFile.txt");
			// to create the writer

			PrintStream writer = new PrintStream(bookFile);
			for (int i = 0; i < booklist.size(); i++) {
				writer.println(booklist.get(i).getStringTOTxt());
				// writer.println(booklist.get(i).getTitle());
				// writer.println(booklist.get(i).getAuthor());
				// writer.println(booklist.get(i).getGenre());
				// writer.println(booklist.get(i).getPublisher());
				// writer.println(booklist.get(i).getShelf());
				// writer.println(booklist.get(i).getCopy());
				// writer.println(booklist.get(i).getTimeBookRentedOut());
			}
			writer.close();// always close the file connection
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		}
	}

	public void readAvailableBooksToFile() {
		try {
			File bookFile = new File("availableBookFile.txt");
			Scanner bookReader;
			bookReader = new Scanner(bookFile);
			String title, author, genre, publisher, shelf;
			int copy, timeBookRentedOut;
			// hasNext() check if there is another line
			while (bookReader.hasNext()) {
				String[] info = bookReader.nextLine().split(",");
				if (info.length >= 7) {
					title = info[0];
					author = info[1];
					genre = info[2];
					publisher = info[3];
					shelf = info[4];
					copy = Integer.parseInt(info[5]);
					timeBookRentedOut = Integer.parseInt(info[6]);
					AvailableBooks book = new AvailableBooks(title, author,
							genre, publisher, shelf);
					book.setCopy(copy);
					book.setTimeBookRentedOut(timeBookRentedOut);
					booklist.add(book);
				}
				// title = bookReader.nextLine();
				// author = bookReader.nextLine();
				// genre = bookReader.nextLine();
				// publisher = bookReader.nextLine();
				// shelf = bookReader.nextLine();
				// copy = bookReader.nextInt();
				// bookReader.nextLine();
				// timeBookRentedOut = bookReader.nextInt();
				// bookReader.nextLine();
				//
				// AvailableBooks book = new AvailableBooks(title, author,
				// genre,
				// publisher, shelf);
				// book.setCopy(copy);
				// book.setTimeBookRentedOut(timeBookRentedOut);
				// booklist.add(book);
			}
			bookReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void saveRentedBooksToFile() {
		try {
			// to create a file
			File bookFile = new File("rentedBookFile.txt");
			// to create the writer

			PrintStream writer = new PrintStream(bookFile);
			for (int i = 0; i < rentedBooklist.size(); i++) {
				// writer.println(rentedBooklist.get(i).getTitle());
				// writer.println(rentedBooklist.get(i).getAuthor());
				// writer.println(rentedBooklist.get(i).getGenre());
				// writer.println(rentedBooklist.get(i).getPublisher());
				// writer.println(rentedBooklist.get(i).getRentOutDate());
				// writer.println(rentedBooklist.get(i).getReturnDate());
				writer.println(rentedBooklist.get(i).getStringTOTxt());
			}
			writer.close();// always close the file connection
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		}
	}

	public void readRentedBooksFromFile() {
		try {
			File bookFile = new File("rentedBookFile.txt");
			Scanner bookReader;
			bookReader = new Scanner(bookFile);
			String title, author, genre, publisher, rentedOutDate, returnDate;
			// hasNext() check if there is another line
			while (bookReader.hasNext()) {
				String[] info = bookReader.nextLine().split(",");
				if (info.length >= 6) {
					title = info[0];
					author = info[1];
					genre = info[2];
					publisher = info[3];
					rentedOutDate = info[4];
					returnDate = info[5];
					RentedBooks book = new RentedBooks(title, author, genre,
							publisher, rentedOutDate, returnDate);
					rentedBooklist.add(book);
				}
				// title = bookReader.nextLine();
				// author = bookReader.nextLine();
				// genre = bookReader.nextLine();
				// publisher = bookReader.nextLine();
				// rentedOutDate = bookReader.nextLine();
				// returnDate = bookReader.nextLine();
				//
				// RentedBooks book = new RentedBooks(title, author, genre,
				// publisher, rentedOutDate, returnDate);
				// rentedBooklist.add(book);
			}
			bookReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void saveUserToFile() {
		try {
			// to create a file
			File userFile = new File("userFile.txt");
			// to create the writer

			PrintStream writer = new PrintStream(userFile);
			writer.flush();
				for (int i = 0; i < userlist.size(); i++) {
					// writer.println(userlist.get(i).getName());
					// writer.println(userlist.get(i).getUserName());
					// writer.println(userlist.get(i).getPassword());
					// writer.println(userlist.get(i).getEmail());
					// writer.println(userlist.get(i).getTeleNumber());
					// writer.println(userlist.get(i).getAdress());
					writer.println(userlist.get(i).getStringTOTxt());
					if (userlist.get(i).history.size() > 0) {
						writer.println("STARTOFHISTORY");
						for (int j = 0; j < userlist.get(i).history.size(); j++) {
							// writer.println(userlist.get(i).history.get(i)
							// .getTitle());
							// writer.println(userlist.get(i).history.get(i)
							// .getAuthor());
							// writer.println(userlist.get(i).history.get(i)
							// .getGenre());
							// writer.println(userlist.get(i).history.get(i)
							// .getPublisher());
							// writer.println(userlist.get(i).history.get(i)
							// .getRentOutDate());
							// writer.println(userlist.get(i).history.get(i)
							// .getReturnDate());
							writer.println(userlist.get(i).history.get(i)
									.getStringTOTxt());
						}
						writer.println("ENDOFHISTORY");
					}
					if (userlist.get(i).rentedBooks.size() > 0) {
						writer.println("STARTOFRENTEDBOOKS");
						for (int j = 0; j < userlist.get(i).rentedBooks.size(); j++) {
							// writer.println(userlist.get(i).rentedBooks.get(i)
							// .getTitle());
							// writer.println(userlist.get(i).rentedBooks.get(i)
							// .getAuthor());
							// writer.println(userlist.get(i).rentedBooks.get(i)
							// .getGenre());
							// writer.println(userlist.get(i).rentedBooks.get(i)
							// .getPublisher());
							// writer.println(userlist.get(i).rentedBooks.get(i)
							// .getRentOutDate());
							// writer.println(userlist.get(i).rentedBooks.get(i)
							// .getReturnDate());

							writer.println(userlist.get(i).rentedBooks.get(i)
									.getStringTOTxt());
						}
						writer.println("ENDOFRENTEDBOOKS");
					}
				}
			writer.close();// always close the file connection
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		}
	}

	public void readUserFromFile() {
		try {
			File userFile = new File("userFile.txt");
			Scanner userReader;
			userReader = new Scanner(userFile);
			String name, userName, password, email, teleNumber, adress;
			// hasNext() check if there is another line
			String info ="";
			if (userReader.hasNext()) {
				info = userReader.nextLine();
			}
			while (info != null && !info.equals("")) {
				String[] userInfo = info.split(",");
				if (userInfo.length >= 6) {
					name = userInfo[0];
					userName = userInfo[1];
					password = userInfo[2];
					email = userInfo[3];
					teleNumber = userInfo[4];
					adress = userInfo[5];

					UserData user = new UserData(name, userName, password,
							email, teleNumber, adress);
					userlist.add(user);

					// name = userReader.nextLine();
					// userName = userReader.nextLine();
					// password = userReader.nextLine();
					// email = userReader.nextLine();
					// teleNumber = userReader.nextLine();
					// adress = userReader.nextLine();
					//
					// UserData user = new UserData(name, userName, password,
					// email,
					// teleNumber, adress);
					// userlist.add(user);
					info ="";
					if (userReader.hasNext()) {
						info = userReader.nextLine();
					}
					if (info != null && !info.equals("")
							&& info.equals("STARTOFHISTORY")) {
						info ="";
						if (userReader.hasNext()) {
							info = userReader.nextLine();
						}
						while (info != null && !info.equals("")) {
							if (!info.equals("ENDOFHISTORY")) {
								String title, author, genre, publisher, rentedOutDate, returnDate;
								String[] infos = info.split(",");
								if (infos.length >= 6) {
									title = infos[0];
									author = infos[1];
									genre = infos[2];
									publisher = infos[3];
									rentedOutDate = infos[4];
									returnDate = infos[5];
									RentedBooks book = new RentedBooks(title,
											author, genre, publisher,
											rentedOutDate, returnDate);
									user.history.add(book);
								}
								info ="";
								if (userReader.hasNext()) {
									info = userReader.nextLine();
								}
							} else {
								break;
							}
							// title = userReader.nextLine();
							// author = userReader.nextLine();
							// genre = userReader.nextLine();
							// publisher = userReader.nextLine();
							// rentedOutDate = userReader.nextLine();
							// returnDate = userReader.nextLine();

							// RentedBooks book = new RentedBooks(title, author,
							// genre, publisher, rentedOutDate, returnDate);
							// user.history.add(book);
						}
					}
					if (info != null && !info.equals("")&& info.equals(
									"STARTOFRENTEDBOOKS")) {
						info ="";
						if (userReader.hasNext()) {
							info = userReader.nextLine();
						}
						while (info != null && !info.equals("")) {
							if (!info.equals("ENDOFRENTEDBOOKS")) {
								String title, author, genre, publisher, rentedOutDate, returnDate;
								String[] infos = info.split(
										",");
								if (infos.length >= 6) {
									title = infos[0];
									author = infos[1];
									genre = infos[2];
									publisher = infos[3];
									rentedOutDate = infos[4];
									returnDate = infos[5];
									RentedBooks book = new RentedBooks(title,
											author, genre, publisher,
											rentedOutDate, returnDate);
									user.rentedBooks.add(book);
								}
								info ="";
								if (userReader.hasNext()) {
									info = userReader.nextLine();
								}
							} else {
								break;
							}
							// String title, author, genre, publisher,
							// rentedOutDate, returnDate;
							// title = userReader.nextLine();
							// author = userReader.nextLine();
							// genre = userReader.nextLine();
							// publisher = userReader.nextLine();
							// rentedOutDate = userReader.nextLine();
							// returnDate = userReader.nextLine();
							//
							// RentedBooks book = new RentedBooks(title, author,
							// genre, publisher, rentedOutDate, returnDate);
							// user.rentedBooks.add(book);
						}
					}
				}
			}
			userReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}