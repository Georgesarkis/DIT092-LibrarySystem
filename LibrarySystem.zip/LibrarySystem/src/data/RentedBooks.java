package data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class RentedBooks extends BookData {
	private String rentOutDate;
	private String dateShouldBeReturn;

	public RentedBooks(String title, String author, String genre,
			String publisher, String rentOutDate, String dateShouldBeReturn) {
		super(title, author, genre, publisher);
		this.rentOutDate = rentOutDate;
		this.dateShouldBeReturn = dateShouldBeReturn;
	}


	public String getRentOutDate() {
		return rentOutDate;
	}

	public void setRentOutDate(String rentOutDate) {
		this.rentOutDate = rentOutDate;
	}

	public String getDateShouldBeReturn() {
		return dateShouldBeReturn;
	}

	public void setDateShouldBeReturn(String dateShouldBeReturn) {
		this.dateShouldBeReturn = dateShouldBeReturn;
	}

	public int exactDay(String returnDate) {
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
		int days = 0;
		try {
			Date date1 = myFormat.parse(this.rentOutDate);
			Date date2 = myFormat.parse(returnDate);
			long diff = date2.getTime() - date1.getTime();
			days = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return days;
	}

	@Override
	public String toString() {
		return this.getTitle() + " written by; " + this.getAuthor()
				+ System.lineSeparator() + "Rented: " + this.getRentOutDate()
				+ " Due Date: " + this.dateShouldBeReturn;
	}
	public String getStringTOTxt() {
		String string = this.getTitle() + "," + this.getAuthor() + ","
				+ this.getGenre() + "," + this.getPublisher() + ","
				+ this.rentOutDate + "," + this.dateShouldBeReturn;

		return string;
	}
}