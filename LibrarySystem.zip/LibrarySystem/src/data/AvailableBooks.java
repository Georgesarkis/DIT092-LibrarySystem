package data;

import java.util.Comparator;

public class AvailableBooks extends BookData {
	private String shelf;
	private int copy;
	private int timesBookBeenRentedOut;
	protected final String END_OF_LINE = System.lineSeparator();

	public AvailableBooks(String title, String author, String genre,
			String publisher, String shelf) {
		super(title, author, genre, publisher);
		this.shelf = shelf;
		this.timesBookBeenRentedOut = 0;
		this.copy = 1;
	}

	public int getCopy() {
		return this.copy;
	}

	public void setCopy(int numberOfCopies) {
		this.copy = numberOfCopies;
	}

	public void addCopy() {
		this.copy = this.copy + 1;
	}

	public String getShelf() {
		return this.shelf;
	}

	public void setShelf(String shelf) {
		this.shelf = shelf;
	}

	public String toString() {
		return ("The book " + this.getTitle() + END_OF_LINE + " written by: "
				+ this.getAuthor() + END_OF_LINE + "the genre is:  "
				+ this.getGenre() + END_OF_LINE + "the publisher : "
				+ this.getPublisher() + END_OF_LINE + "number of copies "
				+ this.copy + END_OF_LINE
				+ "times the book has been rented out "
				+ this.getTimeBookRentedOut() + END_OF_LINE + " is on shelf " + this.shelf);
	}

	public void rentCopy() {
		this.copy = this.copy - 1;
		this.timesBookBeenRentedOut++;
	}

	public int getTimeBookRentedOut() {
		return this.timesBookBeenRentedOut;
	}

	public void setTimeBookRentedOut(int times) {
		this.timesBookBeenRentedOut = times;
	}

	public static Comparator<AvailableBooks> getCompByTitle() {
		Comparator book = new Comparator<AvailableBooks>() {
			public int compare(AvailableBooks b1, AvailableBooks b2) {
				String bookName1 = b1.getTitle().toUpperCase();
				String bookName2 = b2.getTitle().toUpperCase();
				return bookName1.compareTo(bookName2);

			}
		};
		return book;
	}

	public static Comparator<AvailableBooks> getCompByAuthor() {
		Comparator book = new Comparator<AvailableBooks>() {
			public int compare(AvailableBooks b1, AvailableBooks b2) {
				String authorName1 = b1.getAuthor().toUpperCase();
				String authorName2 = b2.getAuthor().toUpperCase();
				return authorName1.compareTo(authorName2);
			}
		};
		return book;
	}

	public static Comparator<AvailableBooks> getCompByTimeRentedOut() {
		Comparator book = new Comparator<AvailableBooks>() {
			@Override
			public int compare(AvailableBooks book1, AvailableBooks book2) {
				return Integer.compareUnsigned(book1.getTimeBookRentedOut(),
						book2.getTimeBookRentedOut());
			}
		};
		return book;
	}

	public String getStringTOTxt() {
		String string = this.getTitle() + "," + this.getAuthor() + ","
				+ this.getGenre() + "," + this.getPublisher() + ","
				+ this.shelf + "," + this.copy + ","
				+ this.timesBookBeenRentedOut;

		return string;
	}
}