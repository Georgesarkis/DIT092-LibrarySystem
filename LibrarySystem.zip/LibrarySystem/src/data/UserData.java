package data;
import java.util.*;

public class UserData {
	private String name, userName, password, email, teleNumber, adress;
	protected final String END_OF_LINE = System.lineSeparator();
	public List<RentedBooks> history; 
	public List<RentedBooks> rentedBooks; //add getters/setters?


	public UserData (String name, String userName, String password, String email, String teleNumber, String adress) {
		this.name = name;
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.teleNumber = teleNumber;
		this.adress = adress;
		this.history = new ArrayList<>();
		this.rentedBooks = new ArrayList<>();
	}
	public String getHistory() {
		return this.history.toString(); //fix toString
	}

	public RentedBooks checkRentedBooks(String name) {
		for(int i=0; i< rentedBooks.size(); i++) {
			if(rentedBooks.get(i).getTitle().equals(name)) {
				return rentedBooks.get(i);
			}
		}
		return null;
	}

	public void setHistory(RentedBooks book) {
		this.history.add(book);
	}


	public void addRentedBook(RentedBooks book) {
		this.rentedBooks.add(book);
	}

	public void deleteRentedBook(RentedBooks book) {
		this.rentedBooks.remove(book);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTeleNumber() {
		return teleNumber;
	}

	public void setTeleNumber(String teleNumber) {
		this.teleNumber = teleNumber;
	}

	public String getAdress() {
		return this.adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String toString() {
		return ("The account " + this.userName + " is owned by " + this.name + ".  " + END_OF_LINE 
				+ "Telephone number: " + this.teleNumber + END_OF_LINE
				+ "Email: " + this.email);
	}
	public String getStringTOTxt() {
		String string = this.name + "," +this.userName + ","
				+ this.password + "," +this.email + ","
				+ this.teleNumber + "," + this.adress;

		return string;
	}
}