package data;

public class ShowBooks {
    private String title;
    private String author;
    private String genre;
    private String publisher;
    private String shelf;
    private String copy;
    private String timesBookBeenRentedOut;

    public ShowBooks(String title, String author, String genre, String publisher, String shelf, String copy, String timesBookBeenRentedOut) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.publisher = publisher;
        this.shelf = shelf;
        this.copy = copy;
        this.timesBookBeenRentedOut = timesBookBeenRentedOut;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getShelf() {
        return shelf;
    }

    public void setShelf(String shelf) {
        this.shelf = shelf;
    }

    public String getCopy() {
        return copy;
    }

    public void setCopy(String copy) {
        this.copy = copy;
    }

    public String getTimesBookBeenRentedOut() {
        return timesBookBeenRentedOut;
    }

    public void setTimesBookBeenRentedOut(String timesBookBeenRentedOut) {
        this.timesBookBeenRentedOut = timesBookBeenRentedOut;
    }
}
